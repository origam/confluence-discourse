using System;
using System.Collections;
using System.Xml;
using System.Data;

using CZ.Advantages.Asap.Workflow;

namespace ServiceAgentExample
{
	/// <summary>
	/// Summary description for TransformationAgent.
	/// </summary>
	public class MyServiceAgent : AbstractServiceAgent
	{
		public MyServiceAgent()
		{
		}

		#region Private Methods
		private object DoSomething(XmlDocument inputParam)
		{
			return null;
		}
		#endregion

		#region IServiceAgent Members
		private object _result;
		public override object Result
		{
			get
			{
				return _result;
			}
		}

		public override void Run()
		{
			switch(this.MethodName)
			{
				case "DoSomething":
					// Check input parameters
					if(! (this.Parameters["InputParam"] is XmlDocument))
						throw new InvalidCastException("InputParam has to be an XML document.");
					
					_result = this.DoSomething(this.Parameters["InputParam"] as XmlDocument);

					break;
			}
		}

		#endregion
	}
}
