﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServiceAgentExample
{
    class XslInterface
    {
        /// <summary>
        /// the function will be available in xsl as well as in Xpath.
        /// usage: MyService:HelloWorld()
        /// 
        /// 
        /// Be carfull tu accept/return only xml compatible datatypes.
        /// For xml input/output the XPathNodeIterator data type is used
        /// output example:
        /// XmlDataDocument xmlDataDoc = new XmlDataDocument(myDataset);
        /// XPathNavigator outNav = xmlDataDoc.CreateNavigator();
        /// return outNav.Select("/"); 
        /// 
        /// </summary>
        /// <returns></returns>
        public string HelloWorld()
        {
            return "Hello World";
        }
    }
}
