using System;
using System.Collections;
using System.Xml;
using System.Data;

using CZ.Advantages.Asap.Services;
using CZ.Advantages.Asap.Workflow;

namespace ServiceAgentExample
{
	/// <summary>
	/// 
    /// ibherit IXslFunctionProvider only if you want to expose some
    /// functionalityto be used in xsl and XPath.
    /// 
	/// </summary>
	public class MyServiceAgent : AbstractServiceAgent, IXslFunctionProvider
	{
		public MyServiceAgent()
		{
		}
		
		private static readonly XslInterface _defaultXslInterface
            = new XslInterface();

		#region Private Methods
		private object DoSomething(XmlDocument inputParam)
		{
			return null;
		}
		#endregion

		#region IServiceAgent Members
		private object _result;
		public override object Result
		{
			get
			{
				return _result;
			}
		}

		public override void Run()
		{
			switch(this.MethodName)
			{
				case "DoSomething":
					// Check input parameters
					if(! (this.Parameters["InputParam"] is XmlDocument))
						throw new InvalidCastException("InputParam has to be an XML document.");
					
					_result = this.DoSomething(this.Parameters["InputParam"] as XmlDocument);

					break;
			}
		}
		#endregion
		
		#region IXslFunctionProvider members
        public string NameSpaceUri
        {
            get
            {
                return "http://my-company.com/MyServiceFunctions";
            }
        }
		
        public string DefaultPrefix
        {
            get
            {
                return "MyService";
            }
        }

        public object XslFunctions
        {
            get
            {
                return _defaultXslInterface;
            }
        }
		#endregion		
	}
}
